
import React, { useState, useEffect } from 'react';
import type { Attendee } from './types';
import Header from './components/Header';
import AddAttendeeForm from './components/AddAttendeeForm';
import AttendeeTable from './components/AttendeeTable';

const App: React.FC = () => {
  const [attendees, setAttendees] = useState<Attendee[]>([]);

  useEffect(() => {
    try {
      const storedAttendees = localStorage.getItem('attendees');
      if (storedAttendees) {
        setAttendees(JSON.parse(storedAttendees));
      }
    } catch (error) {
      console.error("Failed to load attendees from localStorage", error);
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('attendees', JSON.stringify(attendees));
    } catch (error) {
      console.error("Failed to save attendees to localStorage", error);
    }
  }, [attendees]);

  const handleAddAttendee = (newAttendee: Attendee) => {
    setAttendees(prevAttendees => [...prevAttendees, newAttendee]);
  };

  return (
    <>
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        <AddAttendeeForm onAdd={handleAddAttendee} />
        <AttendeeTable attendees={attendees} />
      </main>
    </>
  );
};

export default App;
